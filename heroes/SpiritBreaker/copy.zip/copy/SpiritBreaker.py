import sys

from PyQt5 import uic
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel


class SpiritBreaker(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('hero.ui', self)
        self.setFixedSize(1000, 700)
        self.setStyleSheet(""" background-image: url(backgroundHero.png);
                                      background-repeat: no-repeat;""")
        self.label = QLabel(self)
        self.label.resize(255, 140)
        self.label.move(20, 20)
        self.label.setStyleSheet("""width: 255px;
                                          background-image: url(SpiritBreaker.png);
                                          height: 140px;
                                          border-radius: 15px  """)
        self.label_7.setStyleSheet("""width: 255px;
                                                  background-image: url(Clockwerk.png);
                                                  height: 140px;
                                                  border-radius: 15px;
                                                  color: white;""")
        self.label_6.setStyleSheet("""width: 255px;
                                                  background-image: url(Tiny.png);
                                                  height: 140px;
                                                  border-radius: 15px;
                                                  color: white;""")
        self.label_5.setStyleSheet("""width: 255px;
                                                  background-image: url(reMars.png);
                                                  height: 140px;
                                                  border-radius: 15px;
                                                  color: white;""")
        self.label_4.setStyleSheet("""width: 255px;
                                                  background-image: url(EmberSpirit.png);
                                                  height: 140px;
                                                  border-radius: 15px;
                                                  color: white;""")
        self.label_3.setStyleSheet("""width: 255px;
                                                  background-image: url(Morphling.png);
                                                  height: 140px;
                                                  border-radius: 15px;
                                                  color: white;""")
if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = SpiritBreaker()
    ex.show()
    sys.exit(app.exec_())